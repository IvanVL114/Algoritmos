import java.util.InputMismatchException; //Barrera Nolasco Erick Yahel  2020600004
import java.util.Scanner;
public class SueldosMX {
    public static Scanner sc = new Scanner(System.in);
    public static int max;
    public double sueldos[];
    public double aux;
    public double suma;
    public double promedio;
    public int mPromedio;

    public SueldosMX() {
        this.sueldos = new double [max];
    }
                /////////// METODO PARA CALCULAR EL PROMEDIO DE LOS SUELDOS ///////////
    public void calculoPromedio() {
        suma = 0;
        for (int i = 0; i < sueldos.length; i++) {
            suma += sueldos[i];
            promedio = suma/sueldos.length;
        }  
        System.out.println("\n\tEl promedio de los salarios es de: $ " + promedio);
    }
                /////////// METODO PARA SABER SUELDOS MENOR Y MAYOR ///////////
    public void ordenSueldos() {
        for (int i = 0; i < (max - 1); i++) {
            for (int j = 0; j < (max - 1); j++) {
                if (sueldos[j] > sueldos[j+1]) {
                    aux = sueldos[j];
                    sueldos[j] = sueldos[j+1];
                    sueldos[j+1] = aux;
                }
            }
        }
        System.out.println("\n\tEl sueldo mayor es de: $ " + sueldos[sueldos.length - 1]);
        System.out.println("\n\tEl sueldo menor es de: $ " + sueldos[0]);
    }
    /////////// METODO PARA SABER CUANTOS SUELDOS HAY ARRIBA DEL PROMEDIO ///////////
    public void mayPromedio(){
        int i = 0;
        do{
            i++;
        }while(sueldos[i] <= promedio);
        mPromedio = sueldos.length - i;
        System.out.println("\n\tEl numero de sueldos mayores al promedio es de: " + mPromedio);
        System.out.println("");
    }
        /////////// AQUI VAN LAS VALIDACIONES DE CAPTURA DEL PROGRAMA ///////////
    public static int capEnteros(String mensaje) {
        boolean continuar;
        int  n = 0;
        do {
            continuar = false; 
            try {
                System.out.print(mensaje);
                n = sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("\n\tHay un error: " + e);                    
                System.out.println("\n\tIngresar un numero entero");                                                        
                sc.next();
                continuar = true;
            }             
        } while (continuar);
        return n;
    }

    public static double capMontos(String mensaje) {
        boolean continuar;
        double  n = 0;
        do {
            continuar = false; 
            try {
                System.out.print(mensaje);
                n = sc.nextDouble();
            } catch (InputMismatchException e) {
                System.out.println("\n\tHay un error: " + e);                    
                System.out.println("\n\tIngresar un numero");                                                        
                sc.next();
                continuar = true;
            }             
        } while (continuar);
        return n;
    }
}
