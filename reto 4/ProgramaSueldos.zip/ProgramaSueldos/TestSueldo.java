//Barrera Nolasco Erick Yahel  2020600004
public class TestSueldo {
    public static void main(String[] args) throws Exception {
        SueldosMX.max = SueldosMX.capEnteros("\n\t¿Cuantos sueldos vas a capturar? ");
        System.out.println("");
        SueldosMX sueldo = new SueldosMX();
        for(int i = 0; i < SueldosMX.max; i++) {
            sueldo.sueldos[i] = SueldosMX.capMontos("\tIngresa el " + (i+1) + "° sueldo en pesos y centavos: $");
        }
        sueldo.calculoPromedio();
        sueldo.ordenSueldos();
        sueldo.mayPromedio();
    }
}

